<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Navs extends Model
{
    protected $guarded = [];
}
