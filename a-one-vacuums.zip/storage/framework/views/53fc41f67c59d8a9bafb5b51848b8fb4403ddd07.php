;
<?php $__env->startSection('content'); ?>;

<div id="content" class="main-content">
    <div class="container">
        <div class="container">
            <div class="row">
                <div id="flFormsGrid" class="col-lg-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    <h4>Edit Product</h4>
                                </div>                                                                        
                            </div>
                        </div>
                        <div class="widget-content widget-content-area">
                            <form method="post" action="<?php echo e(url('products/edit'.'/'.$records->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row mb-4">
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Product Name</label>
                                        <input type="text" name="name" value="<?php echo e($records->name); ?>" class="form-control" id="inputEmail4" placeholder="Enter Product Name">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Product Image</label>                                        
                                        <input type="file" name="image" value="<?php echo e($records->image); ?>" class="form-control" id="inputPassword4">
                                        <img src="<?php echo e(url('uploads/products'.'/'.$records->image)); ?>" style="height: 220px; width:400px; border-radius: 30%;">

                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="inputAddress">Product Price</label>
                                    <input type="text" name="price" value="<?php echo e($records->price); ?>" class="form-control" id="inputAddress" placeholder="Enter Product Price">
                                </div>
                                <div class="form-row mb-4">
                                    <div class="form-group col-md-4">
                                        <label for="inputState">Category</label>
                                        <select id="inputState" name="category_id" value="<?php echo e($records->category_id); ?>"  class="form-control">
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option <?php echo e(($category->id == $records->category_id) ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>                                            <?php echo e($category->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    
                                </div>
                                
                            <button type="submit" name="submit" class="btn btn-primary mt-3">Update</button>
                            </form>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a-one-vacuums\resources\views/products/edit.blade.php ENDPATH**/ ?>