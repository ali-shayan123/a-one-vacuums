;
<?php $__env->startSection('content'); ?>;
<div id="content" class="main-content">
    <div class="container">
        <div class="container">
            <div class="row">
                <div id="flFormsGrid" class="col-lg-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    <h4>Edit HomePage</h4>
                                </div>                                                                        
                            </div>
                        </div>
                        <div class="widget-content widget-content-area">
                            <form method="post" action="<?php echo e(url('home/editreview'.'/'.$records->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row mb-4">
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Our_Clients</label>
                                        <input type="text" name="our_clients" value="<?php echo e($records->our_clients); ?>" class="form-control" id="inputEmail4">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Tagline</label>                                        
                                        <input type="text" name="tagline" value="<?php echo e($records->tagline); ?>" class="form-control" id="inputPassword4">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputPassword4">Image</label>                                        
                                    <input type="file" name="image" value="<?php echo e($records->image); ?>" class="form-control" id="inputPassword4">
                                    <img src="<?php echo e(url('uploads/review'.'/'.$records->image)); ?>" style="height: 220px; width:400px; border-radius: 30%;">
                                </div>
                                <div class="form-group mb-4">
                                    <label for="inputAddress">Name</label>
                                    <input type="text" name="name" value="<?php echo e($records->name); ?>" class="form-control" id="inputAddress">
                                </div>
                                <div class="form-group mb-4">
                                    <label for="inputAddress">Description</label>
                                    <input type="text" name="description" value="<?php echo e($records->description); ?>" class="form-control" id="inputAddress">
                                </div>
                                    
                                    
                                
                                
                            <button type="submit" name="submit" class="btn btn-primary mt-3">Update</button>
                            </form>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a-one-vacuums\resources\views/admin/home/editreview.blade.php ENDPATH**/ ?>