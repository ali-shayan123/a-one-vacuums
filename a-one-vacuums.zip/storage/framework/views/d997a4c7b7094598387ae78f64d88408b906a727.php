;
<?php $__env->startSection('content'); ?>;

<div id="content" class="main-content">
            <div class="layout-px-spacing">

                <div class="row layout-top-spacing">
                
                    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                        <div class="widget-content widget-content-area br-6">
                            <table id="default-ordering" class="table table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th class="dt-no-sorting text-center">Id</th>
                                        <th>Image</th>
                                        <th>Welcome note</th>
                                        <th>Span</th>
                                        <th>Tagline</th>
                                        <th>Describe</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                   
                                    <tr>
                                        <td class="text-center"><?php echo e($home1->id); ?></td>
                                        <td><img src="<?php echo e(url('uploads/home').'/'.$home1->banner); ?>" style="height: 72px;"></td>
                                        <td><?php echo e($home1->welcome); ?></td>
                                        <td><?php echo e($home1->span); ?></td>
                                        <td><?php echo e($home1->tagline); ?></td>
                                        <td><?php echo e($home1->describe); ?></td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                               
                            </table>
                            <center><button class="btn btn-primary btn-sm" onclick="location.href='<?php echo e(url('/home/edit/'.$home1->id)); ?>'">Edit</button></center>
                        </div>
                    </div>

                </div>

            </div>

        </div>

<?php $__env->stopSection(); ?>
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="<?php echo e(url('theme')); ?>/plugins/table/datatable/datatables.js"></script>
<script>        
    $('#default-ordering').DataTable( {
        "dom": "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
    "<'table-responsive'tr>" +
    "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
        "oLanguage": {
            "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
            "sInfo": "Showing page _PAGE_ of _PAGES_",
            "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
            "sSearchPlaceholder": "Search...",
           "sLengthMenu": "Results :  _MENU_",
        },
        "order": [[ 3, "desc" ]],
        "stripeClasses": [],
        "lengthMenu": [7, 10, 20, 50],
        "pageLength": 7,
        drawCallback: function () { $('.dataTables_paginate > .pagination').addClass(' pagination-style-13 pagination-bordered'); }
    } );
</script>
<!-- END PAGE LEVEL SCRIPTS -->
  <!-- BEGIN PAGE LEVEL STYLES -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('theme')); ?>/plugins/table/datatable/datatables.css">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('theme')); ?>/plugins/table/datatable/dt-global_style.css">
  <!-- END PAGE LEVEL STYLES -->
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a-one-vacuums\resources\views/admin/home/index.blade.php ENDPATH**/ ?>