
<?php $__env->startSection('title' , "Products"); ?>
<?php $__env->startSection('content'); ?>


<!-- PAGE HEADING & BREADCRUMB START -->
<div id="page-header" class="background-1">
	<div class="container">
		<!-- Heading -->
		<div class="row">
			<div class="col-sm-12">
				<h1>
				Vacuum Cleaners				</h1>
			</div>
		</div>
		<!-- Breadcrumb -->
		<div class="row">
			<div class="col-sm-12">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
					<li class="breadcrumb-item active"><a href="<?php echo e(url('/products')); ?>">Products</a></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!-- PAGE HEADING & BREADCRUMB END -->


<section class="section background-white">
	<div class="container">
		<div class="row">
		<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-sm-3 product-box">
				<!-- Detail -->
				<div class="post-box hvr-float">
					<a href="product99b6.html?brand=sebo&amp;product=sebo-airbelt-e2">
						<img src="<?php echo e(url('theme')); ?><?php echo e($p->image); ?>">
					</a>
					<p style="margin-bottom:5px; font-family:'Montserrat-Bold';"><span style="background:#f5be17; padding:2px 7px; border-radius:4px; color:#eb1d25;">$<?php echo e($p->price); ?></span></p>
					<a href="product99b6.html?brand=sebo&amp;product=sebo-airbelt-e2" class="h3 pname"><?php echo e($p->name); ?></a>
				</div>
			</div>	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
		</div>		
	</div>
</section>


<div class="background-white">
<div class="container">
	<div class="discuss-project-again">
		<div class="row">
			<div class="col-sm-8">
			<h4 class="h1 white-color no-margin">Do you have any question?</h4>
			</div>
			<div class="col-sm-4 m-margin-top m-margin-bottom-10">
				<a href="<?php echo e('/contact'); ?>" class="fright white-btn">Contact Us &nbsp; <i class="fa fa-angle-double-right"></i></a>
			</div>
		</div>
	</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\a-one-vacuums\resources\views/products.blade.php ENDPATH**/ ?>